const styles = theme => ({
  'portal-notes-no-note__container': {
    background: theme.palette.secondary.light
  }
});

export default styles;

const styles = theme => ({
  headerTheme: {
    backgroundColor: theme.palette.primary.main,
    color: theme.palette.text.primary
  },
});

export default styles;

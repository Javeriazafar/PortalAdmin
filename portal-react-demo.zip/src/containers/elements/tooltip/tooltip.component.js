import React, { Component } from 'react';

class Tooltip extends Component {
  render() {
    return (
      <div>
        <h1>Tooltip Example</h1>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>

        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>

        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>

        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>

        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>

        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>

        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>

        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>

        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>

        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>

        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
      </div>
    );
  }
}

export default Tooltip;

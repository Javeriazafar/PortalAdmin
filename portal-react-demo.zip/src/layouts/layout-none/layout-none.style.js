const styles = () => ({
  wrapper: {
    height: '100%'
  }
});

export default styles;

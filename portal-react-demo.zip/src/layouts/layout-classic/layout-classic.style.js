const styles = theme => ({
  wrapper: {
    color: theme.palette.text.primary,
    backgroundColor: theme.palette.background.default
  }
});

export default styles;
